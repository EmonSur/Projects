package org.colourTable;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the ColourTable class.
 */
public class ColourTableTest {
    @Test
    void testConstructorValidSizes() {
        // Valid sizes
        assertDoesNotThrow(() -> new ColourTable(2));
        assertDoesNotThrow(() -> new ColourTable(1024));
    }

    @Test
    void testConstructorInvalidSizes() {
        // Invalid sizes
        assertThrows(IllegalArgumentException.class, () -> new ColourTable(3)); // Non-power of two
        assertThrows(IllegalArgumentException.class, () -> new ColourTable(0)); // Less than 2
        assertThrows(IllegalArgumentException.class, () -> new ColourTable(-1)); // Negative value
    }

    @Test
    void testAddValidRGBValues() {
        ColourTable table = new ColourTable(4);

        // Valid RGB values
        assertDoesNotThrow(() -> table.add(255, 255, 255)); // Maximum RGB
        assertDoesNotThrow(() -> table.add(0, 0, 0)); // Minimum RGB
    }

    @Test
    void testAddInvalidRGBValues() {
        ColourTable table = new ColourTable(4);

        // Invalid RGB values
        assertThrows(IllegalArgumentException.class, () -> table.add(-1, 100, 100)); // Invalid red - too small
        assertThrows(IllegalArgumentException.class, () -> table.add(256, 100, 100)); // Invalid red - too large
        assertThrows(IllegalArgumentException.class, () -> table.add(100, -1, 100)); // Invalid green - too small
        assertThrows(IllegalArgumentException.class, () -> table.add(100, 256, 100)); // Invalid green - too large
        assertThrows(IllegalArgumentException.class, () -> table.add(100, 100, -1)); // Invalid blue - too small
        assertThrows(IllegalArgumentException.class, () -> table.add(100, 100, 256)); // Invalid blue - too large
    }

    @Test
    void testAddExceedsCapacity() {
        ColourTable table = new ColourTable(2); // Create a ColourTable with a capacity of 2

        // Add colors within capacity
        assertDoesNotThrow(() -> table.add(0, 0, 0));
        assertDoesNotThrow(() -> table.add(255, 255, 255));

        // Adding a third color, which exceeds capacity
        assertThrows(IllegalStateException.class, () -> table.add(128, 128, 128));
    }
}

